import pandas as pd
import numpy as np
from datetime import datetime
import sys

current_date = datetime.now()

# Redirect stdout and stderr to log files
sys.stdout = open(r'C:\Users\arian\CSELEC1CLab3\8_data_pipeline_weekly_view.out.log', 'w')
sys.stderr = open(r'C:\Users\arian\CSELEC1CLab3\8_data_pipeline_weekly_view.err.log', 'w')

print("[8: WEEKLY SALES VIEW PER SERVICE]")

### Loading Validated Data
df_merged = pd.read_parquet(r"C:\Users\arian\CSELEC1CLab3\merged_age_restriction.parquet")
print("\nSuccessfully Loaded the Data!")

### Weekly Sales Per Branch
print("\nGenerating Weekly Sales Per Service...")
df_merged['avail_date'] = pd.to_datetime(df_merged['avail_date'])
df_merged.groupby(['service', df_merged['avail_date'].dt.to_period('W')])['price'].sum().to_frame()

### Saving data
df_merged.to_parquet(r"C:\Users\arian\CSELEC1CLab3\merged_weekly_per_service.parquet")
print("\nSuccessfully Saved the Data!")